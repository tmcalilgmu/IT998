FERPA QUANTITATIVE PAPER — RQ3 NOTEBOOK AND RESULTS
Study sample: N = 100 educators from the original FERPA study

RECOMMENDED FILE
  FERPA_RQ3_Statistical_Tests.ipynb

ALTERNATIVE
  FERPA_RQ3_Statistical_Tests.py

REQUIRED SOURCE FILES (not redistributed in this package)
  FERPA Survey July 24 2026 - N100 - Most Recent.xlsx
  FPEPG_October 26, 2026_06.13.csv

HOW TO USE
1. Put the .ipynb file and both source files in the same directory.
2. Open the notebook in JupyterLab, Jupyter Notebook, or VS Code.
3. Use a Python environment with numpy, scipy, statsmodels, matplotlib and ipykernel.
   If needed: pip install numpy scipy statsmodels matplotlib jupyterlab
4. Run All Cells. A folder called RQ3_outputs is created with aggregate results.
5. Alternatively, run: python FERPA_RQ3_Statistical_Tests.py

NOTEBOOK SECTIONS
  1. Setup and reusable utilities
  2. Match the original N=100 study sample; select judgments, risk and comfort
  3. Descriptive risk, comfort and judgment results for nine scenarios
  4. Friedman omnibus tests for risk/comfort and Kendall's W effect sizes
  5. Selected paired Wilcoxon signed-rank tests and Holm adjustment
  6. Risk/comfort Spearman correlations (participant averages, scenario-specific)
     with Holm adjustment for scenario-specific correlations
  7. Selected Kruskal-Wallis comparisons of risk by judgment in S6 and S9
  8. Exploratory ordinal GEE, cluster-robust SEs; exchangeable sensitivity fit
  9. Reporting notes and summary

THE EXPLORATORY GEE
  Five-point risk rating is the ordered outcome.
  Predictors: comfort, self-assessed FERPA knowledge (Q6),
  recent FERPA training (Q15) and scenario indicator variables.
  Clusters: each educator's repeated scenario responses.
  Primary working-correlation assumption: independence, but with
  participant-cluster-robust standard errors.
  Sensitivity assumption: exchangeable working correlation.
  This is an association model, not a causal model. Verify assumptions
  and suitability before using regression results in a publication.

MULTIPLICITY
  A separate Holm family is defined for the selected four paired
  Wilcoxon comparisons (risk and comfort for S7 vs S8 and S4 vs S6).
  Holm adjustments are also provided for nine within-scenario Spearman
  correlations and two selected Kruskal-Wallis comparisons.
  These are kept as separate, explicitly labeled exploratory families.

FILES IN RQ3_outputs
  RQ3_scenario_descriptive_summary.csv
  RQ3_friedman_kendall_w.csv
  RQ3_wilcoxon_selected_pairs_holm.csv
  RQ3_spearman_participant_average.csv
  RQ3_spearman_by_scenario_holm.csv
  RQ3_kruskal_risk_by_judgment_holm.csv
  RQ3_kruskal_group_descriptives.csv
  RQ3_ordinal_GEE_primary_and_sensitivity.csv
  RQ3_risk_comfort_by_scenario.png
  RQ3_risk_comfort_spearman_by_scenario.png

PRIVACY / SCOPE
  Source participant-level data and identifiers are NOT bundled.
  No written response explanations or qualitative coding are analyzed.
  Only aggregate CSV and charts are saved.
  Outputs describe observed associations and group differences, not legal
  correctness. No expert-reference compliance scoring is assumed.

VALIDATION
  Executed successfully with the supplied matching inputs. The notebook
  contains the executed aggregate outputs and plots for inspection.

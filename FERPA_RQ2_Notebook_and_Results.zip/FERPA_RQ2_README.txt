FERPA QUANTITATIVE PAPER — RQ2 NOTEBOOK AND PYTHON SCRIPT
Study sample: N = 100 matched original participants

FILES
  FERPA_RQ2_Statistical_Tests.ipynb — Jupyter Notebook with executed aggregate output
  FERPA_RQ2_Statistical_Tests.py — standalone equivalent Python script
  RQ2_outputs/ — aggregate results (CSVs and charts)

SOURCE DATA REQUIRED (NOT INCLUDED IN THIS ZIP)
Place the following two source files in the same folder as the notebook:
  1. FERPA Survey July 24 2026 - N100 - Most Recent.xlsx
  2. FPEPG_October 26, 2026_06.13.csv

RUN
1. Open the .ipynb in JupyterLab, classic Jupyter, or VS Code.
2. Choose a Python kernel with numpy, scipy, matplotlib installed.
   Example install: python -m pip install numpy scipy matplotlib notebook
3. Use Run All Cells. Aggregate outputs are saved in RQ2_outputs/.
   Alternatively, in a terminal from the input-file folder: python FERPA_RQ2_Statistical_Tests.py

TESTS
- Spearman rho (Q6/Q7/Q8 confidence and knowledge correlations)
- Spearman rho (each score vs count of 'I do not know' across nine scenarios)
- Mann-Whitney U (training vs no training) with signed rank-biserial r
- Kruskal-Wallis H (Q6 knowledge by separate Q3 vignette response)
- Pearson Chi-Square (training by separate Q3 vignette response)
- Holm step-down p adjustments within the three declared three-test families

METHOD NOTES
- The N=100 subset is matched using the original Excel file's Prolific IDs.
- No written explanations are analyzed, and no individual response rows or identifiers are exported.
- Q3 is a separate study question, not one of Scenarios 1-9.
- 'I do not know' counts indicate expressed uncertainty, not legally incorrect answers.
- Legal accuracy requires a reviewed reference rubric; this notebook does not assign correctness labels.
- Ordinal outcomes are compared using ranked/nonparametric tests.
- These are observational relationships and do not establish causation.

"""RQ1: Provisional reference-agreement and grouping analysis for the original N=100 FERPA sample.

Jupyter-ready Python file (# %% cell markers). Companion .ipynb is generated and executed.
Inputs alongside this file:
 - FERPA Survey July 24 2026 - N100 - Most Recent.xlsx
 - FPEPG_October 26, 2026_06.13.csv
 - RQ1_reference_rubric_template.csv (created when absent)

These analyses concern observed agreement with a PROVISIONAL classification, not
legal correctness. Only S2=No, S3=Yes, S5=No are provisionally scored.
"""

# %%
from pathlib import Path
from collections import Counter
import re
import unicodedata
import zipfile
import xml.etree.ElementTree as ET

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats
from scipy.stats import MonteCarloMethod
from statsmodels.stats.multitest import multipletests
from statsmodels.stats.contingency_tables import cochrans_q
from IPython.display import display

BASE = Path.cwd()
N100_WORKBOOK = BASE / "FERPA Survey July 24 2026 - N100 - Most Recent.xlsx"
QUALTRICS_CSV = BASE / "FPEPG_October 26, 2026_06.13.csv"
RUBRIC_FILE = BASE / "RQ1_reference_rubric_template.csv"
OUT = BASE / "RQ1_alignment_outputs"
OUT.mkdir(exist_ok=True)
RESPONSES = ["Yes", "No", "Depends", "I do not know"]
SCENARIOS = [f"Scenario {i}" for i in range(1, 10)]
SEED = 2026
PERMUTATIONS = 9_999
FFH_RESAMPLES = 19_999

for path in [N100_WORKBOOK, QUALTRICS_CSV]:
    if not path.is_file():
        raise FileNotFoundError(f"Missing input: {path.name}. Put it beside the notebook.")

# %%
# Read participant identifiers from the original Excel study workbook using only
# Python's standard-library XLSX XML reader. This avoids a dependency on openpyxl.
# The workbook's first sheet has headings 'Prolific ID' and 'Q1'. The second row
# contains descriptive question text and should not count as a participant.

def first_sheet_rows(path):
    main = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
    with zipfile.ZipFile(path) as archive:
        shared = []
        if "xl/sharedStrings.xml" in archive.namelist():
            root = ET.fromstring(archive.read("xl/sharedStrings.xml"))
            for si in root.findall(f"{main}si"):
                shared.append("".join(t.text or "" for t in si.iter(f"{main}t")))
        xml = archive.read("xl/worksheets/sheet1.xml")
        root = ET.fromstring(xml)
        for row in root.findall(f".//{main}sheetData/{main}row"):
            record = {}
            for cell in row.findall(f"{main}c"):
                ref = cell.get("r", "")
                name = re.match(r"[A-Z]+", ref)
                if not name:
                    continue
                col = name.group(0)
                typ = cell.get("t", "")
                val_el = cell.find(f"{main}v")
                if typ == "inlineStr":
                    val = "".join(t.text or "" for t in cell.iter(f"{main}t"))
                elif val_el is None:
                    val = ""
                elif typ == "s":
                    val = shared[int(val_el.text)]
                else:
                    val = val_el.text or ""
                record[col] = str(val)
            yield record

workbook_rows = list(first_sheet_rows(N100_WORKBOOK))
assert workbook_rows[0].get("E") == "Prolific ID" and workbook_rows[0].get("F") == "Q1", "Unexpected workbook layout"
original_ids = {
    row.get("E", "").strip()
    for row in workbook_rows[2:]
    if row.get("F", "").strip() in {"True", "False", "Unsure"}
    and row.get("E", "").strip()
}
assert len(original_ids) == 100, f"Expected exactly 100 valid study IDs, found {len(original_ids)}"

raw = pd.read_csv(QUALTRICS_CSV, skiprows=[1, 2], dtype=str, keep_default_na=False, low_memory=False)
raw["Prolific ID"] = raw["Prolific ID"].str.strip()
required = ["Prolific ID", "Q23"] + SCENARIOS
if missing := sorted(set(required) - set(raw.columns)):
    raise ValueError(f"Qualtrics export missing columns: {missing}")
df = raw.loc[raw["Prolific ID"].isin(original_ids), required].copy()
assert len(df) == 100 and df["Prolific ID"].nunique() == 100, "Mismatch in the established sample"
for s in SCENARIOS:
    df[s] = df[s].str.strip().replace("", np.nan)
    bad = set(df[s].dropna()) - set(RESPONSES)
    if bad:
        raise ValueError(f"Unexpected judgments in {s}: {bad}")
print(f"Verified original sample: N = {len(df)}")
print("Nine scenario response columns verified; no written explanations were loaded.")

# %%
# Earlier project grouping is DESCRIPTIVE, not an expert-approved legal key.
# Only the three clearly specified cases have a provisional 'expected' judgment.
DEFAULT_RUBRIC = [
    ("Scenario 1", "Named data / contested authorization", "", "Unscored", "Opt-out is not by itself a full account of lawful disclosure"),
    ("Scenario 2", "No student data", "No", "Provisional", "Lecture slides without student information"),
    ("Scenario 3", "Identifiable records / model training", "Yes", "Provisional", "Named grades and model training"),
    ("Scenario 4", "De-identification gray zone", "", "Unscored", "Indirect identifiers may matter"),
    ("Scenario 5", "No student data", "No", "Provisional", "Syllabus revision without student information"),
    ("Scenario 6", "De-identification gray zone", "", "Unscored", "Distinctive writing, small class, possible model training"),
    ("Scenario 7", "De-identification gray zone", "", "Unscored", "Removing names does not establish complete de-identification"),
    ("Scenario 8", "De-identification gray zone", "", "Unscored", "Potential retention / model training after direct identifier removal"),
    ("Scenario 9", "Named data / contested authorization", "", "Unscored", "School-official exception turns on substantive conditions"),
]
if not RUBRIC_FILE.exists():
    pd.DataFrame(DEFAULT_RUBRIC, columns=["Scenario", "Descriptive group", "Reference judgment", "Review status", "Interpretive note"]).to_csv(RUBRIC_FILE, index=False)

rubric = pd.read_csv(RUBRIC_FILE, dtype=str, keep_default_na=False)
assert rubric["Scenario"].tolist() == SCENARIOS, "Rubric must have one ordered row for each scenario"
assert rubric["Reference judgment"].isin(RESPONSES + [""]).all(), "Unexpected reference judgment"
scored = rubric.loc[rubric["Reference judgment"].ne(""), ["Scenario", "Reference judgment", "Review status"]]
assert len(scored) >= 1, "No scored reference items"
print("Provisional reference choices:")
display(scored)
print("Unscored scenarios:", ", ".join(rubric.loc[rubric["Reference judgment"].eq(""), "Scenario"]))

# %%
# Test 1: raw response counts and percentages, preserving all four options.
rows = []
for s in SCENARIOS:
    ct = df[s].value_counts().reindex(RESPONSES, fill_value=0)
    n = int(ct.sum())
    for choice, count in ct.items():
        rows.append({"Scenario": s, "Judgment": choice, "Count": int(count),
                     "Percent": 100 * count / n if n else np.nan, "Valid N": n})
frequency = pd.DataFrame(rows)
frequency.to_csv(OUT / "RQ1_all_response_frequencies.csv", index=False)
display(frequency.pivot(index="Scenario", columns="Judgment", values="Percent").reindex(columns=RESPONSES).round(1))

# %%
# Test 2: Shannon entropy measures dispersion, NOT legal correctness.
def normalized_entropy(counts, k=4):
    a = np.asarray(counts, dtype=float)
    p = a[a > 0] / a.sum()
    return float(-(p * np.log(p)).sum() / np.log(k)) if len(p) else np.nan

entropy = pd.DataFrame([
    {"Scenario": s, "Normalized Shannon entropy": normalized_entropy(
        df[s].value_counts().reindex(RESPONSES, fill_value=0).to_numpy()
    )}
    for s in SCENARIOS
]).merge(rubric[["Scenario", "Descriptive group"]], on="Scenario")
entropy.to_csv(OUT / "RQ1_entropy_by_group.csv", index=False)
display(entropy.round(3))

# %%
# Provisional reference agreement. Use exact binomial confidence intervals as
# descriptive uncertainty intervals; do not present this as expert-validated accuracy.
reference_rows = []
for _, item in scored.iterrows():
    scenario, reference = item["Scenario"], item["Reference judgment"]
    observed = df[scenario].dropna()
    agreements = int(observed.eq(reference).sum())
    ci = stats.binomtest(agreements, len(observed)).proportion_ci(confidence_level=0.95, method="exact")
    reference_rows.append({
        "Scenario": scenario, "Provisional reference": reference,
        "Agreements": agreements, "Valid N": len(observed),
        "Agreement percent": 100 * agreements / len(observed),
        "95% CI lower percent": 100 * ci.low,
        "95% CI upper percent": 100 * ci.high,
        "Review status": item["Review status"],
    })
reference_summary = pd.DataFrame(reference_rows)
reference_summary.to_csv(OUT / "RQ1_provisional_reference_agreement.csv", index=False)
display(reference_summary.round(2))

# Score participant-level joint alignment on the same provisionally scored scenarios.
# The score is NOT a 'total nine-scenario accuracy score'.
reference_map = dict(zip(scored["Scenario"], scored["Reference judgment"]))
for s, choice in reference_map.items():
    df[f"Aligned_{s.replace(' ', '')}"] = df[s].eq(choice).astype(int)
align_cols = [f"Aligned_{s.replace(' ', '')}" for s in reference_map]
df["Provisional agreement count"] = df[align_cols].sum(axis=1)
df["All provisional items matched"] = (df["Provisional agreement count"] == len(align_cols)).astype(int)
score_distribution = (df["Provisional agreement count"].value_counts().sort_index()
                      .rename_axis("Number matched").reset_index(name="Educators"))
score_distribution["Percent"] = 100 * score_distribution["Educators"] / len(df)
score_distribution.to_csv(OUT / "RQ1_participant_agreement_distribution.csv", index=False)
display(score_distribution)
all_match = int(df["All provisional items matched"].sum())
ci_all = stats.binomtest(all_match, len(df)).proportion_ci(confidence_level=0.95, method="exact")
print(f"All {len(reference_map)} provisionally classified scenarios matched: {all_match}/{len(df)} "
      f"({all_match/len(df):.0%}), exact 95% CI [{ci_all.low:.1%}, {ci_all.high:.1%}]")

# %%
# Descriptive four-group profile. These are average within-scenario response percentages.
# This is NOT a legal-accuracy measure. The same educator appears in each scenario.
bucket_profile = frequency.merge(rubric[["Scenario", "Descriptive group"]], on="Scenario")
bucket_profile = (bucket_profile.groupby(["Descriptive group", "Judgment"], as_index=False)
                  .agg({"Percent": "mean"}))
bucket_profile.rename(columns={"Percent": "Mean scenario response percent"}, inplace=True)
bucket_profile.to_csv(OUT / "RQ1_descriptive_group_profiles.csv", index=False)
print("Grouped response patterns (descriptive; do not label as correct/incorrect)")
display(bucket_profile.pivot(index="Descriptive group", columns="Judgment", values="Mean scenario response percent").round(1))

# %%
# Prepare institution comparisons. Q23 institution type is not necessarily identical
# to the originally recruited 50/50 K-12 vs higher-education grouping.
def clean(x):
    return " ".join(unicodedata.normalize("NFKC", str(x)).lower().split())

def group_institution(s):
    x = clean(s)
    if any(word in x for word in ("kindergarten", "elementary", "middle school", "high school")):
        return "K-12"
    if any(word in x for word in ("college", "university", "graduate", "professional school")):
        return "Higher education"
    return np.nan

df["ComparisonGroup"] = df["Q23"].map(group_institution)
GROUP_SOURCE = "Q23 survey-reported institution type"
verified_roster_path = BASE / "rq1_verified_sectors.csv"
if verified_roster_path.exists():
    verified = pd.read_csv(verified_roster_path, dtype=str)
    assert {"Prolific ID", "RecruitmentSector"}.issubset(verified.columns)
    verified["Prolific ID"] = verified["Prolific ID"].str.strip()
    assert verified["Prolific ID"].is_unique
    mapped = df["Prolific ID"].map(verified.set_index("Prolific ID")["RecruitmentSector"])
    assert mapped.isin(["K-12", "Higher education"]).all(), "A verified roster must classify all 100 educators"
    df["ComparisonGroup"] = mapped
    GROUP_SOURCE = "Verified original recruitment sector"
print(GROUP_SOURCE)
print(df["ComparisonGroup"].value_counts(dropna=False))

# %%
# Test 3: permutation Chi-Square for institution type by binary provisional agreement.
# Test 4: Cramer's V effect size. Also give Fisher's exact p for sparse 2x2 tables.
def chi2_table(obs):
    tab = np.asarray(obs, dtype=float)
    tab = tab[:, tab.sum(axis=0) > 0]
    if min(tab.shape) < 2:
        return np.nan, tab
    expected = tab.sum(axis=1)[:, None] * tab.sum(axis=0)[None, :] / tab.sum()
    return float(((tab - expected)**2 / expected).sum()), tab

def permutation_chi2(g, y, n_resamples=9999, seed=2026):
    # g and y are integer arrays encoding two groups and two or more responses.
    g, y = np.asarray(g, int), np.asarray(y, int)
    r, c = 2, int(y.max()) + 1
    observed = np.bincount(g * c + y, minlength=r*c).reshape(r, c)
    statistic, observed = chi2_table(observed)
    if not np.isfinite(statistic):
        return np.nan, np.nan
    rng = np.random.default_rng(seed)
    ge = 0
    for _ in range(n_resamples):
        perm_g = rng.permutation(g)
        tab = np.bincount(perm_g * c + y, minlength=r*c).reshape(r, c)
        perm_stat, _ = chi2_table(tab)
        ge += (perm_stat >= statistic - 1e-12)
    return statistic, (ge + 1)/(n_resamples + 1)

def v_from_chi2(chi2, tab):
    tab = np.asarray(tab, float)
    tab = tab[:, tab.sum(axis=0) > 0]
    denominator = tab.sum() * min(tab.shape[0] - 1, tab.shape[1] - 1)
    return float(np.sqrt(chi2 / denominator)) if np.isfinite(chi2) and denominator > 0 else np.nan

binary_comparisons = []
for i, (s, answer) in enumerate(reference_map.items()):
    data = df.loc[df["ComparisonGroup"].notna(), ["ComparisonGroup", s]].dropna().copy()
    groups = pd.Categorical(data["ComparisonGroup"], categories=["K-12", "Higher education"]).codes
    aligned = data[s].eq(answer).astype(int).to_numpy()
    tab = pd.crosstab(data["ComparisonGroup"], aligned).reindex(index=["K-12", "Higher education"],columns=[0, 1], fill_value=0)
    stat, perm_p = permutation_chi2(groups, aligned, PERMUTATIONS, SEED+i)
    fisher_p = float(stats.fisher_exact(tab.to_numpy()).pvalue)
    binary_comparisons.append({"Scenario": s, "Reference": answer, "Compared N": len(data),
                               "K-12 N": int((groups==0).sum()), "Higher education N": int((groups==1).sum()),
                               "K-12 agreement percent": float(data.loc[data["ComparisonGroup"].eq("K-12"), s].eq(answer).mean()*100),
                               "Higher education agreement percent": float(data.loc[data["ComparisonGroup"].eq("Higher education"), s].eq(answer).mean()*100),
                               "Chi-square": stat, "Permutation p": perm_p,
                               "Cramer's V": v_from_chi2(stat, tab.to_numpy()), "Fisher exact 2x2 p": fisher_p})
binary_comparisons = pd.DataFrame(binary_comparisons)
rej, p_adj, _, _ = multipletests(binary_comparisons["Permutation p"].to_numpy(),method="holm")
binary_comparisons["Holm adjusted p (3 benchmark comparisons)"] = p_adj
binary_comparisons["Significant after Holm"] = rej
binary_comparisons.to_csv(OUT / "RQ1_reference_agreement_group_tests_holm.csv", index=False)
display(binary_comparisons.round(4))

# %%
# Test 5: Fisher-Freeman-Halton for FULL 4-category responses by institution type.
# This is a sensitivity test of response-pattern differences, NOT a test of 'accuracy'.
# Test 6: Holm adjustments for the separate family of nine four-category tests.
full_group_tests = []
for i, s in enumerate(SCENARIOS):
    data = df.loc[df["ComparisonGroup"].notna(), ["ComparisonGroup", s]].dropna()
    group = pd.Categorical(data["ComparisonGroup"],categories=["K-12", "Higher education"]).codes
    choice = pd.Categorical(data[s],categories=RESPONSES).codes
    tab = pd.crosstab(data["ComparisonGroup"], data[s]).reindex(index=["K-12", "Higher education"], columns=RESPONSES, fill_value=0).to_numpy()
    used = tab[:, tab.sum(axis=0)>0]
    chi2, _ = chi2_table(used)
    _, p_perm = permutation_chi2(group, choice, PERMUTATIONS, SEED+20+i)
    v = v_from_chi2(chi2,used)
    expected = used.sum(axis=1)[:,None]*used.sum(axis=0)[None,:]/used.sum()
    sparse = bool((expected < 5).any())
    if used.shape[1] == 2:
        ffh_p = float(stats.fisher_exact(used).pvalue)  # ordinary 2x2 Fisher exact
        exact_method = "Fisher 2x2"
    elif sparse:
        monte_carlo = MonteCarloMethod(n_resamples=FFH_RESAMPLES,
                                      rng=np.random.default_rng(SEED+60+i))
        ffh_p = float(stats.fisher_exact(used, method=monte_carlo).pvalue)
        exact_method = "Fisher-Freeman-Halton Monte Carlo"
    else:
        ffh_p = np.nan
        exact_method = "No sparse cells; not requested"
    full_group_tests.append({"Scenario": s, "Compared N": len(data), "Chi-square": chi2,
                             "Permutation p": p_perm, "Cramer's V": v,
                             "Exact-test type": exact_method, "Exact-test p": ffh_p,
                             "Sparse expected cells": sparse})
full_group_tests = pd.DataFrame(full_group_tests)
rej, p_adj, _, _ = multipletests(full_group_tests["Permutation p"].to_numpy(),method="holm")
full_group_tests["Holm adjusted p (9 judgment comparisons)"] = p_adj
full_group_tests["Significant after Holm"] = rej
full_group_tests.to_csv(OUT / "RQ1_four_category_group_tests_holm.csv", index=False)
display(full_group_tests.round(4))

# %%
# Optional appropriate repeated-measures check, because all provisionally classified
# judgments came from the SAME participants. This is an additional test, not one
# of the original six RQ1 methods.
q = cochrans_q(df[align_cols].to_numpy(dtype=int))
q_result = pd.DataFrame([{"Comparison": "Agreement rates across the provisional scenarios",
                          "Cochran Q": float(q.statistic), "df": int(q.df), "p": float(q.pvalue)}])
q_result.to_csv(OUT / "RQ1_optional_cochran_q.csv", index=False)
display(q_result.round(5))

# %%
# Summary visual and minimal reproducibility statement.
fig, ax = plt.subplots(figsize=(8.3, 4.7))
s = reference_summary
bars = ax.bar(s["Scenario"], s["Agreement percent"], width=.6)
ax.set_ylim(0, 105)
ax.set_ylabel("Agreement with provisional reference (%)")
ax.set_title("Clear-cut FERPA scenarios: provisional reference agreement (N = 100)")
for bar, pct in zip(bars, s["Agreement percent"]):
    ax.text(bar.get_x()+bar.get_width()/2, pct+1, f"{pct:.0f}%",ha="center",va="bottom")
fig.tight_layout()
fig.savefig(OUT / "RQ1_provisional_reference_agreement.png", dpi=160)
plt.show()

print("\nSummary")
print("Provisional reference choices:", reference_map)
print(f"All provisionally classified responses matched: {all_match}/100")
print("Cochran Q p:", float(q.pvalue))
print("Group comparisons remaining significant after Holm (binary agreement):",int(binary_comparisons["Significant after Holm"].sum()))
print("Group comparisons remaining significant after Holm (four categories):",int(full_group_tests["Significant after Holm"].sum()))
print("Institution grouping:",GROUP_SOURCE)
print("Outputs:", OUT.resolve())
print("Interpretation limit: provisional classifications are NOT a reviewed legal answer key.")

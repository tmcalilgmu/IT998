# FERPA Quantitative Study, RQ1 Reference-Agreement Extension

## Scope and data

- **Original study sample:** N = 100, matched by Prolific ID from the original sample workbook to the updated Qualtrics CSV.
- **Files required for a fresh run** (not bundled because they contain participant data):
  - `FERPA Survey July 24 2026 - N100 - Most Recent.xlsx`
  - `FPEPG_October 26, 2026_06.13.csv`
- The notebook deliberately analyzes **only structured scenario judgments** and Q23 institution type. No written explanation coding is included.

## What is and is not scored

The editable `RQ1_reference_rubric_template.csv` records the *provisional* reference judgments. The prefilled classifications are:

| Scenario | Provisional reference |
|:---|:---|
| S2: AI lecture slides without student data | No |
| S3: named student grades entered into a model-training AI service | Yes |
| S5: syllabus revision without student data | No |

S1, S4, S6, S7, S8, and S9 remain **unscored** because a written, expert-reviewed compliance rubric has not been provided. Their responses are reported by descriptive groups instead. This preserves the difference between **agreement with a research team's provisional interpretation** and validated legal accuracy. Do not label a nonagreement as a proven FERPA misunderstanding or violation.

The four scenario groups are descriptive: no student data (S2, S5), identifiable records/model training (S3), de-identification gray zone (S4, S6, S7, S8), and named data/contested authorization (S1, S9).

## Notebook contents

1. Reconstruct and validate the N = 100 sample from the original sample workbook, using Python's standard-library Excel/XML support.
2. Report all four-category response frequencies and normalized Shannon entropy for nine scenarios.
3. Report agreement percentages and exact 95% binomial confidence intervals for the provisionally scored cases; calculate each educator's agreement count.
4. Summarize the four substantive groups descriptively. These are **not** accuracy scores.
5. Compare provisional binary agreement by institution type using permutation Chi-Square, Cramér's V, Fisher exact (2x2), and Holm adjustment across the three comparisons.
6. Compare full four-category judgment patterns using permutation Chi-Square, Cramér's V, Fisher-Freeman-Halton exact/Monte Carlo where sparse, and a **separate** Holm adjustment across nine scenario comparisons.
7. Optionally test paired binary agreement rates for the three scored scenarios with Cochran's Q (same participants in each scenario).
8. Export aggregate CSV tables and a bar chart to `RQ1_alignment_outputs/`.

**Important sector caveat:** The Q23-derived institution groups classify 99 respondents, with one 'Other' respondent left unclassified. The descriptive and reference-agreement results still use all N = 100. Q23 institution type should not be silently equated with the original recruitment-sector groups. If an original verified sector roster is available, add `rq1_verified_sectors.csv` with columns `Prolific ID` and `RecruitmentSector` using `K-12` and `Higher education`.

**Software:** Python 3.10+, NumPy, pandas, SciPy 1.15+ (for larger-table exact Monte Carlo), statsmodels, matplotlib, IPython/Jupyter.

## Reproducibility

Put the notebook, the editable rubric CSV, and the two original input files in one folder, and select **Run All**. The companion `.py` contains `# %%` cell markers and can be opened in VS Code as a notebook-like script.

Permutation and Monte Carlo exact p-values have deterministic random seeds. Repeated runs should reproduce the results with the same software versions. Their Monte Carlo precision depends on the configured number of resamples.

## Principal results in the current file

- S2: 98/100 selected the provisional `No` response.
- S3: 95/100 selected the provisional `Yes` response.
- S5: 95/100 selected the provisional `No` response.
- Exactly 89/100 matched all three provisional responses; 10/100 matched two; 1/100 matched one.
- Cochran's Q comparing these *paired* agreement rates: p = .441, no statistically significant evidence of a difference across the three.
- No Q23 institution-type association with benchmark alignment survived Holm adjustment, and no four-category scenario association survived the separate Holm adjustment.
- S6 had the highest response entropy (0.905), but it is **not** assigned a binary correctness label.

All conclusions are observational and reflect judgments, not proven legal accuracy or causal effects.

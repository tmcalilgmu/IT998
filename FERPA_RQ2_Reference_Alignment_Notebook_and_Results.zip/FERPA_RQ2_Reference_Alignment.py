"""RQ2: FERPA knowledge, confidence and provisional scenario-reference agreement.

Jupyter-ready script with # %% cell boundaries.

Inputs placed alongside this file:
  FERPA Survey July 24 2026 - N100 - Most Recent.xlsx
  FPEPG_October 26, 2026_06.13.csv

Uses EXACTLY the original 100 participants. The only provisionally scored
scenario judgments are S2=No, S3=Yes and S5=No. This is NOT a validated legal
accuracy analysis for all nine scenarios.

Statistical methods: Spearman, Mann-Whitney U, rank-biserial effect sizes,
Kruskal-Wallis, Chi-Square, Fisher exact sensitivity, and Holm correction.
Only aggregate outputs are exported; no participant-level or written responses.
"""

# %%
# 1. Imports, paths, and documented provisional classification
from pathlib import Path
from zipfile import ZipFile
from xml.etree import ElementTree as ET
from collections import Counter
import csv
import re

import numpy as np
import matplotlib.pyplot as plt
from scipy import stats

BASE = Path.cwd()
ORIGINAL_XLSX = BASE / "FERPA Survey July 24 2026 - N100 - Most Recent.xlsx"
QUALTRICS_CSV = BASE / "FPEPG_October 26, 2026_06.13.csv"
OUT = BASE / "RQ2_reference_outputs"
OUT.mkdir(exist_ok=True)

EXPECTED_JUDGMENTS = {"Scenario 2": "No", "Scenario 3": "Yes", "Scenario 5": "No"}
SCENARIO_LIST = list(EXPECTED_JUDGMENTS)
Q3_CATEGORIES = ["Yes", "No", "Unsure"]
ALPHA = 0.05
for path in (ORIGINAL_XLSX, QUALTRICS_CSV):
    if not path.exists():
        raise FileNotFoundError(f"Required input missing: {path.name}. Put it beside the notebook.")


def save_csv(name, rows, fieldnames):
    """Save only aggregate statistical results; never participant-level records."""
    with (OUT / name).open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for r in rows:
            writer.writerow({k: r.get(k, "") for k in fieldnames})


def display_rows(label, rows, keys):
    print("\n" + label)
    if not rows:
        print("(no rows)")
        return
    widths = {k: max(len(k), *(len(str(r.get(k, ""))) for r in rows)) for k in keys}
    print(" | ".join(k.ljust(widths[k]) for k in keys))
    print("-+-".join("-" * widths[k] for k in keys))
    for row in rows:
        print(" | ".join(str(row.get(k, "")).ljust(widths[k]) for k in keys))


def holm(p_values):
    """Family-wise Holm adjusted p-values, returned in the input order."""
    p = np.asarray(p_values, dtype=float)
    if np.any(~np.isfinite(p)) or np.any((p < 0) | (p > 1)):
        raise ValueError("Holm correction needs finite p-values between 0 and 1.")
    order = np.argsort(p)
    out = np.empty(len(p), dtype=float)
    previous = 0.0
    for rank, i in enumerate(order):
        previous = max(previous, min(1.0, float((len(p) - rank) * p[i])))
        out[i] = previous
    return out


def p_text(value):
    return "< .001" if value < .001 else f"{value:.4f}"

print("RQ2 provisional-alignment analysis. Planned study sample: N = 100.")
print("Reference classifications:", EXPECTED_JUDGMENTS)

# %%
# 2. Identify the same 100 participants as the original study
# The original workbook has one questionnaire-description row and a nonresponse
# placeholder. Read the XLSX archive with Python's standard library and retain
# only distinct Prolific IDs with a valid original Q1 answer.
NS = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}


def xlsx_col_index(cell_ref):
    match = re.match(r"[A-Z]+", cell_ref)
    if match is None:
        raise ValueError(f"Unrecognized cell reference: {cell_ref}")
    result = 0
    for char in match.group(0):
        result = result * 26 + ord(char) - ord("A") + 1
    return result - 1


def original_ids_from_workbook(path):
    with ZipFile(path) as z:
        shared = []
        if "xl/sharedStrings.xml" in z.namelist():
            string_root = ET.fromstring(z.read("xl/sharedStrings.xml"))
            for item in string_root.findall("m:si", NS):
                shared.append("".join((t.text or "") for t in item.findall(".//m:t", NS)))
        sheet = ET.fromstring(z.read("xl/worksheets/sheet1.xml"))
        rows = []
        for xml_row in sheet.findall(".//m:sheetData/m:row", NS):
            row = {}
            for cell in xml_row.findall("m:c", NS):
                col = xlsx_col_index(cell.attrib["r"])
                typ = cell.attrib.get("t")
                value_el = cell.find("m:v", NS)
                if typ == "s" and value_el is not None:
                    value = shared[int(value_el.text)]
                elif typ == "inlineStr":
                    value = "".join((t.text or "") for t in cell.findall(".//m:t", NS))
                else:
                    value = value_el.text if value_el is not None else ""
                row[col] = str(value or "").strip()
            rows.append(row)
    if not rows:
        raise ValueError("Original sample workbook has no rows.")
    header = {value: col for col, value in rows[0].items() if value}
    if "Prolific ID" not in header or "Q1" not in header:
        raise ValueError("Original workbook does not have the expected ID and Q1 fields.")
    id_col, q1_col = header["Prolific ID"], header["Q1"]
    ids = {row.get(id_col, "") for row in rows[1:]
           if row.get(id_col, "") and row.get(q1_col, "") in {"True", "False", "Unsure"}}
    if len(ids) != 100:
        raise AssertionError(f"Expected 100 original-study participants; got {len(ids)}")
    return ids


valid_ids = original_ids_from_workbook(ORIGINAL_XLSX)
fields = ["Prolific ID", "Q1", "Q2", "Q3", "Q6_1", "Q7_1", "Q8_1", "Q15"] + SCENARIO_LIST
with QUALTRICS_CSV.open("r", encoding="utf-8-sig", newline="") as file:
    reader = csv.reader(file)
    header = next(reader)
    next(reader)  # Full Qualtrics question wording
    next(reader)  # Qualtrics metadata
    missing = sorted(set(fields) - set(header))
    if missing:
        raise ValueError(f"Missing Qualtrics columns: {missing}")
    # The scenario headers appear twice; their FIRST occurrence is the judgment.
    col = {name: header.index(name) for name in fields}
    records = []
    for raw_row in reader:
        identifier = raw_row[col["Prolific ID"]].strip()
        if identifier in valid_ids:
            records.append({name: raw_row[index].strip() for name, index in col.items()})

ids = [row["Prolific ID"] for row in records]
if len(records) != 100 or len(set(ids)) != 100:
    raise AssertionError("Expected precisely 100 unique matched study responses.")
for r in records:
    for field, low, high in [("Q6_1", 0, 10), ("Q7_1", 1, 5), ("Q8_1", 1, 5)]:
        value = float(r[field])
        if not low <= value <= high:
            raise ValueError(f"Unexpected {field} value")
        r[field] = value
    if r["Q15"] not in {"Yes", "No"} or r["Q3"] not in Q3_CATEGORIES:
        raise ValueError("Unexpected training or Q3 category")
    for item in SCENARIO_LIST:
        if r[item] not in {"Yes", "No", "Depends", "I do not know"}:
            raise ValueError(f"Unexpected judgment for {item}")
print("Matched participants:", len(records))
print("Recent training groups:", dict(Counter(r["Q15"] for r in records)))
print("No open-ended survey answers loaded or exported.")

# %%
# 3. Agreement counts and descriptive summaries
# Matching the provisional reference in all three scenarios is a descriptive
# agreement measure. Do not describe it as legal accuracy or total accuracy
# over the nine scenarios.
q6 = np.array([r["Q6_1"] for r in records], float)
q7 = np.array([r["Q7_1"] for r in records], float)
q8 = np.array([r["Q8_1"] for r in records], float)
trained = np.array([r["Q15"] == "Yes" for r in records], bool)
q3_vignette = np.array([r["Q3"] for r in records], object)

item_match = {item: np.array([r[item] == expected for r in records], bool)
              for item, expected in EXPECTED_JUDGMENTS.items()}
agreement_count = np.sum(np.column_stack(list(item_match.values())).astype(int), axis=1)
all_matched = (agreement_count == len(SCENARIO_LIST))
assert len(agreement_count) == 100
assert int(all_matched.sum()) == 89, "This data no longer matches the prior reference-agreement run"

summary = []
for name, values in item_match.items():
    count = int(values.sum())
    ci = stats.binomtest(count, 100).proportion_ci(confidence_level=.95, method="exact")
    summary.append({"Outcome": name, "Expected response": EXPECTED_JUDGMENTS[name],
                    "Matched": count, "N": 100, "Percent matched": count,
                    "95% CI low percent": 100*ci.low, "95% CI high percent": 100*ci.high})
count = int(all_matched.sum())
ci = stats.binomtest(count, 100).proportion_ci(confidence_level=.95, method="exact")
summary.append({"Outcome": "All 3 provisional scenarios", "Expected response": "S2=No; S3=Yes; S5=No",
                "Matched": count, "N": 100, "Percent matched": count,
                "95% CI low percent": 100*ci.low, "95% CI high percent": 100*ci.high})
display_rows("Provisional scenario-reference agreement", summary,
             ["Outcome", "Expected response", "Matched", "N", "Percent matched"])
save_csv("RQ2_provisional_agreement_summary.csv", summary,
         ["Outcome", "Expected response", "Matched", "N", "Percent matched", "95% CI low percent", "95% CI high percent"])
score_distribution = [{"Number of provisional matches": i, "Educators": int(np.sum(agreement_count == i))}
                      for i in range(len(SCENARIO_LIST)+1)]
save_csv("RQ2_agreement_score_distribution.csv", score_distribution,
         ["Number of provisional matches", "Educators"])
print("Number of provisional matches:", dict(Counter(map(int, agreement_count))))

# %%
# 4. Spearman associations of Q6, Q7, Q8 with provisional agreement count
# The three correlations are a single planned family for Holm adjustment.
self_assessments = [
    ("Q6 self-assessed FERPA knowledge", q6),
    ("Q7 general compliance confidence", q7),
    ("Q8 safe-student-data confidence", q8),
]
spearman_results = []
for name, predictor in self_assessments:
    test = stats.spearmanr(predictor, agreement_count)
    spearman_results.append({"Predictor": name, "N": 100,
                             "Spearman rho": float(test.statistic),
                             "Unadjusted p": float(test.pvalue)})
for row, adj in zip(spearman_results, holm([r["Unadjusted p"] for r in spearman_results])):
    row["Holm-adjusted p"] = float(adj)
    row["Significant after Holm"] = bool(adj < ALPHA)
display_rows("Spearman: provisional agreement count vs self-reported measures", [
    {**r, "Spearman rho": f"{r['Spearman rho']:.3f}",
     "Unadjusted p": p_text(r["Unadjusted p"]), "Holm-adjusted p": p_text(r["Holm-adjusted p"])}
    for r in spearman_results
], ["Predictor", "Spearman rho", "Unadjusted p", "Holm-adjusted p", "Significant after Holm"])
save_csv("RQ2_agreement_spearman_holm.csv", spearman_results,
         ["Predictor", "N", "Spearman rho", "Unadjusted p", "Holm-adjusted p", "Significant after Holm"])

# %%
# 5. Mann-Whitney U and signed rank-biserial effect sizes
# Compare Q6/Q7/Q8 between educators who matched all three provisional
# classifications and educators who missed at least one. Small n in the latter
# group means these exploratory comparisons have low power.
matched_vs_not = []
for name, measure in self_assessments:
    yes, no = measure[all_matched], measure[~all_matched]
    test = stats.mannwhitneyu(yes, no, alternative="two-sided", method="asymptotic")
    signed_rb = (2 * float(test.statistic) / (len(yes) * len(no))) - 1
    matched_vs_not.append({"Measure": name, "All matched N": len(yes), "Not all matched N": len(no),
                           "All matched median": float(np.median(yes)),
                           "Not all matched median": float(np.median(no)),
                           "U": float(test.statistic), "Rank-biserial r": signed_rb,
                           "Unadjusted p": float(test.pvalue)})
for row, adj in zip(matched_vs_not, holm([r["Unadjusted p"] for r in matched_vs_not])):
    row["Holm-adjusted p"] = float(adj)
    row["Significant after Holm"] = bool(adj < ALPHA)
display_rows("Mann-Whitney U: self-reported measures by all-three agreement", [
    {**r, "Rank-biserial r": f"{r['Rank-biserial r']:.3f}",
     "Unadjusted p": p_text(r["Unadjusted p"]),
     "Holm-adjusted p": p_text(r["Holm-adjusted p"])}
    for r in matched_vs_not
], ["Measure", "All matched median", "Not all matched median", "Rank-biserial r", "Unadjusted p", "Holm-adjusted p"])
save_csv("RQ2_agreement_mann_whitney_rank_biserial_holm.csv", matched_vs_not,
         ["Measure", "All matched N", "Not all matched N", "All matched median", "Not all matched median",
          "U", "Rank-biserial r", "Unadjusted p", "Holm-adjusted p", "Significant after Holm"])

# %%
# 6. Recent training: Mann-Whitney rank comparison and Chi-Square association
# The aggregate score is ordinal with a strong ceiling effect. The binary
# all-three matched table can be tested by Chi-Square. We additionally report
# Fisher's exact two-sided test as a small-cell sensitivity check.
trained_scores, untrained_scores = agreement_count[trained], agreement_count[~trained]
test_u = stats.mannwhitneyu(trained_scores, untrained_scores, alternative="two-sided", method="asymptotic")
signed_rb = 2*float(test_u.statistic)/(len(trained_scores)*len(untrained_scores)) - 1
training_mw = [{"Comparison": "Training versus agreement count", "Trained N": len(trained_scores),
                "Untrained N": len(untrained_scores), "Trained median": float(np.median(trained_scores)),
                "Untrained median": float(np.median(untrained_scores)), "U": float(test_u.statistic),
                "Rank-biserial r": signed_rb, "Unadjusted p": float(test_u.pvalue)}]
save_csv("RQ2_training_agreement_mann_whitney.csv", training_mw, list(training_mw[0]))
print("Training vs agreement count: U=%.2f, rank-biserial=%.3f, p=%s" %
      (test_u.statistic, signed_rb, p_text(test_u.pvalue)))

table = np.array([
    [int(np.sum(trained & all_matched)), int(np.sum(trained & ~all_matched))],
    [int(np.sum(~trained & all_matched)), int(np.sum(~trained & ~all_matched))]
], dtype=int)
chi_stat, chi_p, dof, expected = stats.chi2_contingency(table, correction=False)
fisher = stats.fisher_exact(table, alternative="two-sided")
association = [{"Comparison": "Recent training vs agreement on all 3 provisional scenarios",
                "N": 100, "Chi-Square": float(chi_stat), "df": int(dof),
                "Chi-Square p": float(chi_p), "Minimum expected cell": float(expected.min()),
                "Fisher exact p": float(fisher.pvalue), "Fisher odds ratio": float(fisher.statistic)}]
print("Rows: trained, untrained. Columns: all three matched, at least one mismatch.")
print("Observed:\n", table)
print("Expected:\n", np.round(expected, 2))
print("Chi-Square(1)=%.4f, p=%s; Fisher exact p=%s" %
      (chi_stat, p_text(chi_p), p_text(fisher.pvalue)))
save_csv("RQ2_training_agreement_chi_square_fisher.csv", association, list(association[0]))

# %%
# 7. Kruskal-Wallis: agreement count across separate Q3 vignette categories
# Q3 is the stand-alone vignette in the survey, NOT Scenario 3.
# Groups Yes, No and Unsure are independent respondents.
groups = [agreement_count[q3_vignette == response] for response in Q3_CATEGORIES]
kruskal = stats.kruskal(*groups)
kruskal_rows = [{"Comparison": "Provisional agreement count by separate Q3 response",
                 "N": 100, "H statistic": float(kruskal.statistic), "df": 2,
                 "p": float(kruskal.pvalue)}]
save_csv("RQ2_agreement_kruskal_q3.csv", kruskal_rows, list(kruskal_rows[0]))
for name, group in zip(Q3_CATEGORIES, groups):
    print(f"Separate Q3 = {name}: n={len(group)}, median provisional matches={np.median(group):.1f}")
print(f"Kruskal-Wallis H={kruskal.statistic:.4f}; p={p_text(kruskal.pvalue)}")

# %%
# 8. Exploratory objective-knowledge item indicators (NOT a legal scoring key)
# Q1 True, Q2 contains BOTH full name and course grade, Q3 Yes regarding potential
# risk. Q2 may contain extra choices; this is 'both identified', NOT strict
# correctness. The three Q indicators are checked separately, and we do not
# present their sum as a validated FERPA knowledge scale.
q1_true = np.array([r["Q1"] == "True" for r in records], dtype=bool)
q2_both = np.array(["The student’s full name" in r["Q2"] and
                    "The student’s overall course grade" in r["Q2"] for r in records], dtype=bool)
q2_exact = np.array([set(r["Q2"].split(",")) == {"The student’s full name", "The student’s overall course grade"}
                     for r in records], dtype=bool)
q3_risk_yes = (q3_vignette == "Yes")
indicators = [("Q1 = True", q1_true), ("Q2 = both name and grade selected", q2_both),
              ("Q3 = Yes, potential risk", q3_risk_yes)]
item_results = []
for label, indicator in indicators:
    ct = np.array([[np.sum(all_matched & indicator), np.sum(all_matched & ~indicator)],
                   [np.sum(~all_matched & indicator), np.sum(~all_matched & ~indicator)]], dtype=int)
    exact = stats.fisher_exact(ct, alternative="two-sided")
    item_results.append({"Item indicator": label, "Item endorsed N": int(indicator.sum()),
                         "Matched all 3 and endorsed": int(ct[0, 0]),
                         "Did not match all 3 and endorsed": int(ct[1, 0]),
                         "Fisher exact p": float(exact.pvalue)})
for row, adj in zip(item_results, holm([r["Fisher exact p"] for r in item_results])):
    row["Holm-adjusted p"] = float(adj)
    row["Significant after Holm"] = bool(adj < ALPHA)
save_csv("RQ2_exploratory_knowledge_indicators_fisher_holm.csv", item_results,
         ["Item indicator", "Item endorsed N", "Matched all 3 and endorsed", "Did not match all 3 and endorsed",
          "Fisher exact p", "Holm-adjusted p", "Significant after Holm"])
print("Q2 both selected:", int(q2_both.sum()), "Q2 exactly these two:", int(q2_exact.sum()))
display_rows("Exploratory Q1/Q2/Q3 indicator associations with reference agreement", [
    {**r, "Fisher exact p": p_text(r["Fisher exact p"]),
     "Holm-adjusted p": p_text(r["Holm-adjusted p"])} for r in item_results
], ["Item indicator", "Item endorsed N", "Fisher exact p", "Holm-adjusted p", "Significant after Holm"])

# %%
# 9. Per-scenario training comparisons, using Fisher exact for rare mismatches
# If we ask about each individual reference classification instead of the
# combined all-three outcome, the number of mismatches is small. Fisher's
# exact test is preferable to relying on a Chi-Square approximation.
scenario_training = []
for item, mask in item_match.items():
    ct = np.array([[np.sum(trained & mask), np.sum(trained & ~mask)],
                   [np.sum(~trained & mask), np.sum(~trained & ~mask)]], dtype=int)
    exact = stats.fisher_exact(ct, alternative="two-sided")
    scenario_training.append({"Scenario": item, "Reference": EXPECTED_JUDGMENTS[item],
                              "Trained matched": int(ct[0, 0]), "Trained N": int(np.sum(trained)),
                              "Untrained matched": int(ct[1, 0]), "Untrained N": int(np.sum(~trained)),
                              "Fisher exact p": float(exact.pvalue)})
for row, adj in zip(scenario_training, holm([r["Fisher exact p"] for r in scenario_training])):
    row["Holm-adjusted p"] = float(adj)
    row["Significant after Holm"] = bool(adj < ALPHA)
save_csv("RQ2_training_by_individual_reference_scenario_holm.csv", scenario_training,
         ["Scenario", "Reference", "Trained matched", "Trained N", "Untrained matched", "Untrained N",
          "Fisher exact p", "Holm-adjusted p", "Significant after Holm"])
display_rows("Training by individual provisional classification", [
    {**r, "Fisher exact p": p_text(r["Fisher exact p"]),
     "Holm-adjusted p": p_text(r["Holm-adjusted p"])} for r in scenario_training
], ["Scenario", "Reference", "Trained matched", "Untrained matched", "Fisher exact p", "Holm-adjusted p"])

# %%
# 10. Two charts and final verification
fig, ax = plt.subplots(figsize=(7, 4.5))
trained_match = 100 * int(np.sum(trained & all_matched)) / int(np.sum(trained))
untrained_match = 100 * int(np.sum(~trained & all_matched)) / int(np.sum(~trained))
bars = ax.bar(["Recent training", "No recent training"], [trained_match, untrained_match])
ax.set_ylim(0, 110)
ax.set_ylabel("Matched all three provisional classifications (%)")
ax.set_title("Provisional agreement by FERPA training (N = 100)")
for bar, value in zip(bars, [trained_match, untrained_match]):
    ax.text(bar.get_x() + bar.get_width()/2, value+2, f"{value:.1f}%", ha="center")
fig.tight_layout()
fig.savefig(OUT / "RQ2_reference_agreement_by_training.png", dpi=160)
plt.show()

fig, ax = plt.subplots(figsize=(7, 4.5))
ax.boxplot([q6[all_matched], q6[~all_matched]], tick_labels=["Matched all three", "Missed at least one"])
ax.set_ylabel("Self-assessed FERPA knowledge (0 to 10)")
ax.set_title("Self-assessed knowledge vs provisional reference agreement")
fig.tight_layout()
fig.savefig(OUT / "RQ2_knowledge_by_provisional_agreement.png", dpi=160)
plt.show()

print("\nAnalysis completed for exactly N = 100.")
print("Confirmed matched all three:", int(all_matched.sum()))
print("Training match counts:", int(np.sum(trained & all_matched)), "/", int(np.sum(trained)),
      "vs", int(np.sum(~trained & all_matched)), "/", int(np.sum(~trained)))
print("All outputs:")
for path in sorted(OUT.iterdir()):
    if path.is_file():
        print("  ", path.name)
print("\nLimitations: provisional classifications only; strong ceiling effect; independent educators = 100.")
print("No qualitative codebook or written explanations used.")

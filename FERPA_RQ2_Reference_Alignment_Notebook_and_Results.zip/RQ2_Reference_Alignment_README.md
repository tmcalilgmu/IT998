# FERPA RQ2: Provisional Reference Agreement

This analysis uses only the original **N = 100** participants and the following provisional scenario classifications:

- Scenario 2: **No**
- Scenario 3: **Yes**
- Scenario 5: **No**

The remaining six scenarios are deliberately **not scored**. Agreement with a provisional classification is not the same as expert-validated legal accuracy.

## Input files

Keep these files in the same directory as the notebook or `.py` script:

1. `FERPA Survey July 24 2026 - N100 - Most Recent.xlsx`
2. `FPEPG_October 26, 2026_06.13.csv`

No additional file is required. The script reads the original 100-person roster from the first workbook and matches to the current Qualtrics export by Prolific ID. It uses the first occurrence of each scenario column, which contains the categorical judgment, and excludes explanatory text.

## How to run

- Notebook: open `FERPA_RQ2_Reference_Alignment.ipynb` in JupyterLab or VS Code and choose **Run All**.
- Script: run `python FERPA_RQ2_Reference_Alignment.py` from the folder containing both input files.
- Required packages: `numpy`, `scipy`, and `matplotlib`; the notebook itself also needs a Python kernel.

The script writes aggregate CSV tables and two charts into `RQ2_reference_outputs/`. It does not export any participant identifiers or response text. The ZIP contains the executed notebook, the Python source, and the aggregate outputs. It does not redistribute raw survey data.

## Included statistical tests

- Exact binomial confidence intervals and frequencies for agreement with the three provisional classifications
- Spearman correlations between agreement count and Q6, Q7, Q8, with Holm adjustment
- Mann-Whitney U and signed rank-biserial effects comparing knowledge/confidence by matching all three, with Holm adjustment
- Mann-Whitney U and rank-biserial effect comparing agreement count by recent FERPA training
- Chi-Square and Fisher exact sensitivity test of training by matching all three
- Kruskal-Wallis comparison of agreement count across the separate Q3 vignette judgment groups
- Exploratory Fisher exact comparisons of three knowledge-item indicators, with Holm adjustment
- Per-scenario Fisher exact training comparisons, with Holm adjustment

## Interpretation safeguards

- The **three-scenario agreement measure is not a nine-scenario accuracy score** or an approved legal answer key.
- Matching all three is common, leaving relatively few mismatches and limiting statistical precision.
- The Chi-Square training comparison has adequate expected cell counts in this specific table, but Fisher's exact test is supplied as a sensitivity analysis.
- Unadjusted p-values must not be reported as though they remained significant after Holm correction.
- The independent sample is 100 educators. Tests using an aggregate score have one observation per educator.
- The study is observational. Training associations must not be interpreted as training effects.
- Q2's exploratory indicator counts people who selected both the student's full name and course grade even if they selected other options. A strict exactly-two response is counted separately for transparency.
- No written explanations, codebook development, or inter-rater agreement tests are included.
